#!/usr/bin/env sh

./pack_via.sh
./pack_via_basic_demo.sh
./pack_via_face_demo.sh
./pack_via_wikimedia_demo.sh


./pack_via_face_track_annotation_demo.sh
mv ../via_face_track_annotation_demo.html /home/tlm/dev/vgg_software/via/docs/data/face_track_annotation/via_face_track_annotation_demo.html
cp ../via.html /home/tlm/dev/vgg_software/via/docs/data/face_track_annotation/
